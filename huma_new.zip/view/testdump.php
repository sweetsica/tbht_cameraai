<?php

$datadump = '1211';
$datadump2 = 'Huy căn cứt';
$datadump3 = array(
    'hote' => 'Huy cứt',
    'tuoi' => '12'
);
var_dump($datadump3);
echo $datadump."<br>";
echo $datadump2."<br>";
print_r($datadump3);
?>